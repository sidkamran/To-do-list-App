const d=new Date();
document.getElementById("date").innerText=d.toDateString();



function getData(){
    if(document.querySelector("input").value.length==0){
        alert("Please add a task")
    }
    else{
        document.getElementById("result").innerHTML
        += `<div class="task"><span id="taskname">${document.querySelector("input").value}</span><button class="delete" onclick="del()">X</button></div>`;
    }
}
 function del(){
let current_value=document.getElementsByClassName("delete");

for(let i=0;i<current_value.length;i++){
    current_value[i].onclick= function (){
        this.parentNode.remove();
    }
}
}